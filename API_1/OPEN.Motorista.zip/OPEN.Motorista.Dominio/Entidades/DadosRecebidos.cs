﻿using System;

namespace OPEN.Motorista.Dominio.Entidades
{
    public class DadosRecebidos
    {
        public Pessoa documentopessoa { get; set; }
        public char  datarecebido { get; set; }
        public Item item { get; set; }
        public Int32 quantidade { get; set; }
        public Int32 situacao { get; set; }
        public string msg { get; set; }
        public char excluido { get; set; }





    }
}
