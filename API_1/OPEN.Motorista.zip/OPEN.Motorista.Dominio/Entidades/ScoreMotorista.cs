﻿using OPEN.Motorista.Dominio.Entidades;
using System;

namespace OPEN.Motorista.Dominio.Entidades
{
    public class ScoreMotorista
    {
        public Int64 documentopessoa { get; set; }
        public Perfil cdperfil { get; set; }
        public Clientes cdcliente { get; set; }
        public Int64 score { get; set; }
        public DateTime dtcalculo { get; set; }
        public char excluido { get; set; }
        public string msg { get; set; }



    }
}
