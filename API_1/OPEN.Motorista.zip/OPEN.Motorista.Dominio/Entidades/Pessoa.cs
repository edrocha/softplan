﻿using System;

namespace OPEN.Motorista.Dominio.Entidades
{
    public class Pessoa
    {
        public Int64 Nome { get; set; }
        public Int64  documentopessoa { get; set; }
        public char excluido { get; set; }
        public string msg { get; set; }

    }
}
