﻿using System;

namespace OPEN.Motorista.Dominio.Entidades
{
    public class Veiculos
    {
        public Int64 cdVeiculo { get; set; }
        public Int64 placa { get; set; }
        public string   tipoveiculo { get; set; }
        public string msg { get; set; }
        public char excluido { get; set; }

    }
}
