﻿using System;

namespace OPEN.Motorista.Dominio.Entidades
{
    public class Item
    {
        public Int64 cdItem { get; set; }
        public string   nomeItem { get; set; }
        public string msg { get; set; }
        public char excluido { get; set; }

    }
}
