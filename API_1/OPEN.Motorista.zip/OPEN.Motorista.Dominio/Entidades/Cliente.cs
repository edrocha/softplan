﻿using System;

namespace OPEN.Motorista.Dominio.Entidades
{
    public class Clientes
    {
        public Int64 cdCliente { get; set; }
        public string   nomeCliente { get; set; }
        public string msg { get; set; }
        public char excluido { get; set; }


    }
}
