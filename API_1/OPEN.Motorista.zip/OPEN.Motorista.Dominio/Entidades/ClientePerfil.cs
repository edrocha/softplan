﻿using System;

namespace OPEN.Motorista.Dominio.Entidades
{
    public class ClientePerfil
    {
        public Int64 cdCliente { get; set; }
        public Int64  cdPerfil { get; set; }
        public string msg { get; set; }
        public char excluido { get; set; }



    }
}
