﻿using System;

namespace OPEN.Motorista.Dominio.Entidades
{
    public class Perfil
    {
        public Int64 cdperfil { get; set; }
        public string  nomeperfil { get; set; }
        public char excluido { get; set; }
        public string msg { get; set; }
    }
}
