﻿using System;

namespace OPEN.Motorista.Dominio.Entidades
{
    public class ItemPerfil
    {
        public Int64 cditem { get; set; }
        public Int64 valoritem { get; set; }
        public Int64 cdperfil { get; set; }
        public char excluido { get; set; }
        public string msg { get; set; }




    }
}
