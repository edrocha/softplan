﻿using OPEN.Motorista.Dominio.Entidades;

namespace OPEN.Motorista.Dominio.Interfaces
{
    public interface IItemPerfil: IBase<ItemPerfil>
    {
    }
}
