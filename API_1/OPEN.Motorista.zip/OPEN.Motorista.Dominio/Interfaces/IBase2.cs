﻿using System.Collections.Generic;

namespace OPEN.Motorista.Dominio.Interfaces
{
    public interface IBase2<T> where T : class
    {
        T Cadastrar(T obj);
        T Deletar(T obj);
    }
}
