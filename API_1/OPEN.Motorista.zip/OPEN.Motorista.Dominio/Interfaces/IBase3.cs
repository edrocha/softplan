﻿using System.Collections.Generic;

namespace OPEN.Motorista.Dominio.Interfaces
{
    public interface IBase3<T> where T : class
    {
        List<T> Obter(int id);
    }
}
