﻿using System.Collections.Generic;

namespace OPEN.Motorista.Dominio.Interfaces
{
    public interface IBase<T> where T : class
    {
        T Cadastrar(T obj);
        T Alterar(T obj);
        List<T> Obter(int id);
        T Deletar(T obj);
    }
}
