﻿using OPEN.Motorista.Dominio.Entidades;

namespace OPEN.Motorista.Dominio.Interfaces
{
    public interface IItem: IBase<Item>
    {
    }
}
