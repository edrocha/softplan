using OPEN.Motorista.Infra.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OPEN.Motorista.Teste
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ValidarConnectionString()
        {
           new  Contexto().TesteConnection();
        }



    }
}
