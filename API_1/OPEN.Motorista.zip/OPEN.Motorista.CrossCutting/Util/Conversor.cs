﻿namespace OPEN.Motorista.CrossCutting.Util
{
    public static class Conversor
    {
        public static bool ConversorSimNao(string SimNao)
        {
            if (SimNao == "S") return true;
            else return false;
        }
    }
}
