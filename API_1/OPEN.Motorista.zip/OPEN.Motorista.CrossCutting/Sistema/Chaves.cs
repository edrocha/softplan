﻿namespace OPEN.Motorista.CrossCutting.Sistema
{
    public class Chaves
    {
        public string ConnectionString { get; set; }

        public Chaves()
        {
            //Provisório
            ConnectionString = "Data Source=25.57.33.28/CPSD02;User Id=WGERENTE;Password=produca0;";
        }
    }
}
