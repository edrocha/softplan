using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.Aplicacao;
using OPEN.Motorista.Infra.Repositorios;
using OPEN.Motorista.Dominio.Interfaces;
using System;
using Microsoft.OpenApi.Models;

namespace OPEN.Motorista.Servico
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddSwaggerGen();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "OPEN WebServices",
                    Description = "API ecosistema para microservi�o",
                    TermsOfService = new Uri("https://example.com/terms")
                });
            });

         
            services.AddTransient<IClientes, ClientesRepositorio>();
            services.AddTransient<IClientesAplicacao, ClientesAplicacao>();

            services.AddTransient<IClientePerfil, ClientePerfilRepositorio>();
            services.AddTransient<IClientePerfilAplicacao, ClientePerfilAplicacao>();

            services.AddTransient<IPerfil, PerfilRepositorio>();
            services.AddTransient<IPerfilAplicacao, PerfilAplicacao>();

            services.AddTransient<IItem, ItemRepositorio>();
            services.AddTransient<IItemAplicacao, ItemAplicacao>();

            services.AddTransient<IItemPerfil, ItemPerfilRepositorio>();
            services.AddTransient<IItemPerfilAplicacao, ItemPerfilAplicacao>();


            services.AddTransient<IScoreMotorista, ScoreMotoristaRepositorio>();
            services.AddTransient<IScoreMotoristaAplicacao, ScoreMotoristaAplicacao>();

            services.AddTransient<IScoreVeiculos, ScoreVeiculosRepositorio>();
            services.AddTransient<IScoreVeiculosAplicacao, ScoreVeiculosAplicacao>();

        }
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
   


            app.UseSwagger(c =>
            {
                c.SerializeAsV2 = true;
            });

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
           
            });

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
