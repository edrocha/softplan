﻿using System.Collections.Generic;
using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.Dominio.Entidades;
using Microsoft.AspNetCore.Mvc;

namespace OPEN.Motorista.Servico.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemPerfilController : ControllerBase
    {
        public IItemPerfilAplicacao _ItemPerfilAplicacao { get; set; }

        public ItemPerfilController(IItemPerfilAplicacao ItemPerfilAplicacao)
        {
            _ItemPerfilAplicacao = ItemPerfilAplicacao;
        }
        // GET: api/MarcaEmpresa
        [HttpGet]
        public IEnumerable<ItemPerfil> ObterItemPerfil(int id)
        {
            return _ItemPerfilAplicacao.Obter(id);
        }

        // GET: api/MarcaEmpresa
        [HttpPost]
        public ItemPerfil CadastrarItemPerfil(ItemPerfil ItemPerfil)
        {
            return _ItemPerfilAplicacao.Cadastrar(ItemPerfil);
        }

        [HttpPut]
        public ItemPerfil AlterarItemPerfil(ItemPerfil ItemPerfil)
        {
            return _ItemPerfilAplicacao.Alterar(ItemPerfil);
        }

        [HttpDelete]
        public ItemPerfil DeleteItemPerfil(ItemPerfil ItemPerfil)
        {
            return _ItemPerfilAplicacao.Deletar(ItemPerfil);
        }
    }
}
