﻿using System.Collections.Generic;
using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.Dominio.Entidades;
using Microsoft.AspNetCore.Mvc;

namespace OPEN.Motorista.Servico.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DadosRecebidosController : ControllerBase
    {
        public IDadosRecebidosAplicacao _DadosRecebidosAplicacao { get; set; }

        public DadosRecebidosController(IDadosRecebidosAplicacao DadosRecebidosAplicacao)
        {
            _DadosRecebidosAplicacao = DadosRecebidosAplicacao;
        }
        // GET: api/MarcaEmpresa
        [HttpGet]
        public IEnumerable<DadosRecebidos> ObterDadosRecebidos(int id)
        {
            return _DadosRecebidosAplicacao.Obter(id);
        }

        // GET: api/MarcaEmpresa
        [HttpPost]
        public DadosRecebidos CadastrarDadosRecebidos(DadosRecebidos DadosRecebidos)
        {
            return _DadosRecebidosAplicacao.Cadastrar(DadosRecebidos);
        }

        [HttpPut]
        public DadosRecebidos AlterarDadosRecebidos(DadosRecebidos DadosRecebidos)
        {
            return _DadosRecebidosAplicacao.Alterar(DadosRecebidos);
        }

        [HttpDelete]
        public DadosRecebidos DeleteDadosRecebidos(DadosRecebidos DadosRecebidos)
        {
            return _DadosRecebidosAplicacao.Deletar(DadosRecebidos);
        }
    }
}
