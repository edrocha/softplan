﻿using System.Collections.Generic;
using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.Dominio.Entidades;
using Microsoft.AspNetCore.Mvc;

namespace OPEN.Motorista.Servico.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VeiculosController : ControllerBase
    {
        public IVeiculosAplicacao _VeiculosAplicacao { get; set; }

        public VeiculosController(IVeiculosAplicacao VeiculosAplicacao)
        {
            _VeiculosAplicacao = VeiculosAplicacao;
        }
        // GET: api/MarcaEmpresa
        [HttpGet]
        public IEnumerable<Veiculos> ObterVeiculos(int id)
        {
            return _VeiculosAplicacao.Obter(id);
        }

        // GET: api/MarcaEmpresa
        [HttpPost]
        public Veiculos CadastrarVeiculos(Veiculos Veiculos)
        {
            return _VeiculosAplicacao.Cadastrar(Veiculos);
        }

        [HttpPut]
        public Veiculos AlterarVeiculos(Veiculos Veiculos)
        {
            return _VeiculosAplicacao.Alterar(Veiculos);
        }

        [HttpDelete]
        public Veiculos DeleteVeiculos(Veiculos Veiculos)
        {
            return _VeiculosAplicacao.Deletar(Veiculos);
        }
    }
}
