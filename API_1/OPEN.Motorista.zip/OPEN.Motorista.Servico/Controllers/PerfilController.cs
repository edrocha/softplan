﻿using System.Collections.Generic;
using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.Dominio.Entidades;
using Microsoft.AspNetCore.Mvc;

namespace OPEN.Motorista.Servico.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PerfilController : ControllerBase
    {
        public IPerfilAplicacao _PerfilAplicacao { get; set; }

        public PerfilController(IPerfilAplicacao PerfilAplicacao)
        {
            _PerfilAplicacao = PerfilAplicacao;
        }
        // GET: api/MarcaEmpresa
        [HttpGet]
        public IEnumerable<Perfil> ObterPerfil(int id)
        {
            return _PerfilAplicacao.Obter(id);
        }

        // GET: api/MarcaEmpresa
        [HttpPost]
        public Perfil CadastrarPerfil(Perfil Perfil)
        {
            return _PerfilAplicacao.Cadastrar(Perfil);
        }

        [HttpPut]
        public Perfil AlterarPerfil(Perfil Perfil)
        {
            return _PerfilAplicacao.Alterar(Perfil);
        }

        [HttpDelete]
        public Perfil DeletePerfil(Perfil Perfil)
        {
            return _PerfilAplicacao.Deletar(Perfil);
        }
    }
}
