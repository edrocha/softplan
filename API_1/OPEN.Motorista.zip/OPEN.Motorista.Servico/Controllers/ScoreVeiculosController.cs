﻿using System.Collections.Generic;
using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.Dominio.Entidades;
using Microsoft.AspNetCore.Mvc;

namespace OPEN.Motorista.Servico.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ScoreVeiculosController : ControllerBase
    {
        public IScoreVeiculosAplicacao _ScoreVeiculosAplicacao { get; set; }

        public ScoreVeiculosController(IScoreVeiculosAplicacao ScoreVeiculosAplicacao)
        {
            _ScoreVeiculosAplicacao = ScoreVeiculosAplicacao;
        }
        // GET: api/MarcaEmpresa
        [HttpGet]
        public IEnumerable<ScoreVeiculos> ObterScoreVeiculos(int idpessoa)
        {
            return _ScoreVeiculosAplicacao.Obter(idpessoa);
        }
        
    }
}
