﻿using System.Collections.Generic;
using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.Dominio.Entidades;
using Microsoft.AspNetCore.Mvc;

namespace OPEN.Motorista.Servico.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientePerfilController : ControllerBase
    {
        public IClientePerfilAplicacao _ClientePerfilAplicacao { get; set; }

        public ClientePerfilController(IClientePerfilAplicacao ClientePerfilAplicacao)
        {
            _ClientePerfilAplicacao = ClientePerfilAplicacao;
        }

        // GET: api/MarcaEmpresa
        [HttpPost]
        public ClientePerfil CadastrarCliente(ClientePerfil cliente)
        {
            return _ClientePerfilAplicacao.Cadastrar(cliente);
        }

        [HttpDelete]
        public ClientePerfil DeleteCliente(ClientePerfil cliente)
        {
            return _ClientePerfilAplicacao.Deletar(cliente);
        }
    }
}
