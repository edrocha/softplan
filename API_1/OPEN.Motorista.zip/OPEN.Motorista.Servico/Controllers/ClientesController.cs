﻿using System.Collections.Generic;
using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.Dominio.Entidades;
using Microsoft.AspNetCore.Mvc;

namespace OPEN.Motorista.Servico.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientesController : ControllerBase
    {
        public IClientesAplicacao _ClientesAplicacao { get; set; }

        public ClientesController(IClientesAplicacao clientesAplicacao)
        {
            _ClientesAplicacao = clientesAplicacao;
        }
        // GET: api/MarcaEmpresa
        [HttpGet]
        public IEnumerable<Clientes> ObterCliente(int id)
        {
            return _ClientesAplicacao.Obter(id);
        }

        // GET: api/MarcaEmpresa
        [HttpPost]
        public Clientes CadastrarCliente(Clientes cliente)
        {
            return _ClientesAplicacao.Cadastrar(cliente);
        }

        [HttpPut]
        public Clientes AlterarCliente(Clientes cliente)
        {
            return _ClientesAplicacao.Alterar(cliente);
        }

        [HttpDelete]
        public Clientes DeleteCliente(Clientes cliente)
        {
            return _ClientesAplicacao.Deletar(cliente);
        }
    }
}
