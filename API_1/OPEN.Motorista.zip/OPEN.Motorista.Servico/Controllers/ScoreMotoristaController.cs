﻿using System.Collections.Generic;
using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.Dominio.Entidades;
using Microsoft.AspNetCore.Mvc;

namespace OPEN.Motorista.Servico.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ScoreMotoristaController : ControllerBase
    {
        public IScoreMotoristaAplicacao _ScoreMotoristaAplicacao { get; set; }

        public ScoreMotoristaController(IScoreMotoristaAplicacao ScoreMotoristaAplicacao)
        {
            _ScoreMotoristaAplicacao = ScoreMotoristaAplicacao;
        }
        // GET: api/MarcaEmpresa
        [HttpGet]
        public IEnumerable<ScoreMotorista> ObterScoreMotorista(int idpessoa)
        {
            return _ScoreMotoristaAplicacao.Obter(idpessoa);
        }
        
    }
}
