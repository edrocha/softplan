﻿using System.Collections.Generic;
using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.Dominio.Entidades;
using Microsoft.AspNetCore.Mvc;

namespace OPEN.Motorista.Servico.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        public IItemAplicacao _ItemAplicacao { get; set; }

        public ItemController(IItemAplicacao ItemAplicacao)
        {
            _ItemAplicacao = ItemAplicacao;
        }
        // GET: api/MarcaEmpresa
        [HttpGet]
        public IEnumerable<Item> ObterItem(int id)
        {
            return _ItemAplicacao.Obter(id);
        }

        // GET: api/MarcaEmpresa
        [HttpPost]
        public Item CadastrarItem(Item Item)
        {
            return _ItemAplicacao.Cadastrar(Item);
        }

        [HttpPut]
        public Item AlterarItem(Item Item)
        {
            return _ItemAplicacao.Alterar(Item);
        }

        [HttpDelete]
        public Item DeleteItem(Item Item)
        {
            return _ItemAplicacao.Deletar(Item);
        }
    }
}
