﻿
using OPEN.Motorista.Infra.Data;
using System;

namespace OPEN.Motorista.TesteConsole
{
    class Program
    {
        static void Main(string[] args)
        {

            new MarcaTeste().Marcas();
           // new UnidadeTeste().Unidades();

            Console.WriteLine("Hello World!");
        }
    }
}
