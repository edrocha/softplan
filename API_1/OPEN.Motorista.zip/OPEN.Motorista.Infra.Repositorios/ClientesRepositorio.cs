﻿using Microsoft.Extensions.Configuration;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using OPEN.Motorista.Dominio.Interfaces;
using OPEN.Motorista.Infra.Data;
using System;
using System.Collections.Generic;
using System.Text;


namespace OPEN.Motorista.Infra.Repositorios
{
    public class ClientesRepositorio : IClientes
    {
        
        IConfiguration _configuration;

        public ClientesRepositorio(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public Clientes Cadastrar(Clientes obj)
        {
            try
            {
                var data = new ClientesData(_configuration).InserirCliente(obj);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Contexto/TesteConnection", ex);
            }
            return null;
        }

        public Clientes Alterar(Clientes obj)
        {
            try
            {
                var data = new ClientesData(_configuration).AlterarCliente(obj);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Repositorio/AlterarCliente", ex);
            }
            return null;
        }

        
           

        public List<Clientes> Obter(int id)
        {

            try
            {
                var data = new ClientesData(_configuration).ObterCliente(id);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Contexto/TesteConnection", ex);
            }
            return null;
        }

        public Clientes Deletar(Clientes obj)
        {
            try
            {
                var data = new ClientesData(_configuration).DeleteCliente(obj);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Repositorio/DeleteCliente", ex);
            }
            return null;
        }
    }
}




