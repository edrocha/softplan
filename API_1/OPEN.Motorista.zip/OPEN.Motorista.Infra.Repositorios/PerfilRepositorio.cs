﻿using Microsoft.Extensions.Configuration;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using OPEN.Motorista.Dominio.Interfaces;
using OPEN.Motorista.Infra.Data;
using System;
using System.Collections.Generic;
using System.Text;


namespace OPEN.Motorista.Infra.Repositorios
{
    public class PerfilRepositorio : IPerfil
    {
        
        IConfiguration _configuration;

        public PerfilRepositorio(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public Perfil Cadastrar(Perfil obj)
        {
            try
            {
                var data = new PerfilData(_configuration).InserirPerfil(obj);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Contexto/TesteConnection", ex);
            }
            return null;
        }

        public Perfil Alterar(Perfil obj)
        {
            try
            {
                var data = new PerfilData(_configuration).AlterarPerfil(obj);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Repositorio/AlterarPerfil", ex);
            }
            return null;
        }

        
           

        public List<Perfil> Obter(int id)
        {

            try
            {
                var data = new PerfilData(_configuration).ObterPerfil(id);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Contexto/TesteConnection", ex);
            }
            return null;
        }

        public Perfil Deletar(Perfil obj)
        {
            try
            {
                var data = new PerfilData(_configuration).DeletePerfil(obj);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Repositorio/DeletePerfil", ex);
            }
            return null;
        }
    }
}




