﻿using Microsoft.Extensions.Configuration;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using OPEN.Motorista.Dominio.Interfaces;
using OPEN.Motorista.Infra.Data;
using System;
using System.Collections.Generic;
using System.Text;


namespace OPEN.Motorista.Infra.Repositorios
{
    public class VeiculosRepositorio : IVeiculos
    {
        
        IConfiguration _configuration;

        public VeiculosRepositorio(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public Veiculos Cadastrar(Veiculos obj)
        {
            try
            {
                var data = new VeiculosData(_configuration).InserirVeiculos(obj);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Contexto/TesteConnection", ex);
            }
            return null;
        }

        public Veiculos Alterar(Veiculos obj)
        {
            try
            {
                var data = new VeiculosData(_configuration).AlterarVeiculos(obj);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Repositorio/AlterarVeiculos", ex);
            }
            return null;
        }

        
           

        public List<Veiculos> Obter(int id)
        {

            try
            {
                var data = new VeiculosData(_configuration).ObterVeiculos(id);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Contexto/TesteConnection", ex);
            }
            return null;
        }

        public Veiculos Deletar(Veiculos obj)
        {
            try
            {
                var data = new VeiculosData(_configuration).DeleteVeiculos(obj);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Repositorio/DeleteVeiculos", ex);
            }
            return null;
        }
    }
}




