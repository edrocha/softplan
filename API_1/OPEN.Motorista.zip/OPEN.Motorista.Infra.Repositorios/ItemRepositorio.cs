﻿using Microsoft.Extensions.Configuration;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using OPEN.Motorista.Dominio.Interfaces;
using OPEN.Motorista.Infra.Data;
using System;
using System.Collections.Generic;
using System.Text;


namespace OPEN.Motorista.Infra.Repositorios
{
    public class ItemRepositorio : IItem
    {
        
        IConfiguration _configuration;

        public ItemRepositorio(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public Item Cadastrar(Item obj)
        {
            try
            {
                var data = new ItemData(_configuration).InserirItem(obj);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Contexto/TesteConnection", ex);
            }
            return null;
        }

        public Item Alterar(Item obj)
        {
            try
            {
                var data = new ItemData(_configuration).AlterarItem(obj);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Repositorio/AlterarItem", ex);
            }
            return null;
        }

        
           

        public List<Item> Obter(int id)
        {

            try
            {
                var data = new ItemData(_configuration).ObterItem(id);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Contexto/TesteConnection", ex);
            }
            return null;
        }

        public Item Deletar(Item obj)
        {
            try
            {
                var data = new ItemData(_configuration).DeleteItem(obj);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Repositorio/DeleteItem", ex);
            }
            return null;
        }
    }
}




