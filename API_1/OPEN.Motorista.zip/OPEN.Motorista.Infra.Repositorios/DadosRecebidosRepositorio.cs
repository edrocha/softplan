﻿using Microsoft.Extensions.Configuration;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using OPEN.Motorista.Dominio.Interfaces;
using OPEN.Motorista.Infra.Data;
using System;
using System.Collections.Generic;
using System.Text;


namespace OPEN.Motorista.Infra.Repositorios
{
    public class DadosRecebidosRepositorio : IDadosRecebidos
    {
        
        IConfiguration _configuration;

        public DadosRecebidosRepositorio(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public DadosRecebidos Alterar(DadosRecebidos obj)
        {
            throw new NotImplementedException();
        }

        public Dominio.Entidades.DadosRecebidos Cadastrar(Dominio.Entidades.DadosRecebidos obj)
        {
            try
            {
                var data = new DadosRecebidosData(_configuration).InserirDadosRecebidos(obj);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Contexto/TesteConnection", ex);
            }
            return null;
        }

        public DadosRecebidos Deletar(DadosRecebidos obj)
        {
            throw new NotImplementedException();
        }

        public List<DadosRecebidos> Obter(int id)
        {

            try
            {
                var data = new DadosRecebidosData(_configuration).ObterDadosRecebidos(id);
                return data;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Contexto/TesteConnection", ex);
            }
            return null;
        }

        
    }
}




