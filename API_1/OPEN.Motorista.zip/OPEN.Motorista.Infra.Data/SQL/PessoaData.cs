﻿using Dapper;
using Microsoft.Extensions.Configuration;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace OPEN.Motorista.Infra.Data
{
    public class PessoaData
    {
        IConfiguration _configuration;

        public PessoaData(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GetConnection()
        {
            var connection = _configuration.GetSection("ConnectionStrings").
            GetSection("DefaultConnection").Value;
            return connection;
        }
        public  virtual List<Pessoa> ObterPessoa(int? id = 0)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                try
                {
                    con.Open();
                    var query = "SELECT nome FROM Pessoa WHERE documentopessoa=" + id+" and excluido='N'";
                    var data = con.Query<Pessoa>(query).ToList();
                    return data;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }



        public virtual Pessoa InserirPessoa(Pessoa obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var Pessoa = new Pessoa(); 
                try
                {
                    con.Open();
                    var query = "INSERT INTO Pessoa (documentopessoa, nome) VALUES (" + obj.documentopessoa + ",'" + obj.Nome + "')";
                    con.Execute(query);
                    Pessoa.documentopessoa = obj.documentopessoa;
                    Pessoa.Nome = obj.Nome; 
                    Pessoa.msg = "Incluido com Sucesso";
                    return Pessoa;
                }
                catch (Exception ex)
                {
                    Pessoa.msg = "Erro ao tentar Incluir verifique no log";
                    return Pessoa;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
        public virtual Pessoa AlterarPessoa(Pessoa obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var Pessoa = new Pessoa();
                try
                {
                    con.Open();
                    var query = "UPDATE Pessoa SET nome='" + obj.Nome + "' WHERE documentopessoa=" + obj.documentopessoa;
                    con.Execute(query);
                    Pessoa.documentopessoa = obj.documentopessoa;
                    Pessoa.Nome = obj.Nome;
                    Pessoa.msg = "Alterado com Sucesso";
                    return Pessoa;
                }
                catch (Exception ex)
                {
                    Pessoa.msg = "Erro ao tentar Alterar verifique no log a causa";
                    return Pessoa;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }




        public virtual Pessoa DeletePessoa(Pessoa obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var Pessoa = new Pessoa();
                try
                {
                    con.Open();
                    var query = "UPDATE Pessoa SET excluido='S' WHERE documentopessoa=" + obj.documentopessoa;
                    con.Execute(query);
                    Pessoa.documentopessoa = obj.documentopessoa;
                    Pessoa.Nome = obj.Nome;
                    Pessoa.msg = "Pessoa Excluido com Sucesso";
                    return Pessoa;
                }
                catch (Exception ex)
                {
                    Pessoa.msg = "Erro ao tentar Excluir o Pessoa verifique no log a causa";
                    return Pessoa;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
