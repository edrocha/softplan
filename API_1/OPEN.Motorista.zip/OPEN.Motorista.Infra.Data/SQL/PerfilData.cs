﻿using Dapper;
using Microsoft.Extensions.Configuration;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace OPEN.Motorista.Infra.Data
{
    public class PerfilData
    {
        IConfiguration _configuration;

        public PerfilData(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GetConnection()
        {
            var connection = _configuration.GetSection("ConnectionStrings").
            GetSection("DefaultConnection").Value;
            return connection;
        }
        public  virtual List<Perfil> ObterPerfil(int? id = 0)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                try
                {
                    con.Open();
                    var query = "SELECT cdPerfil, nomePerfil FROM Perfil WHERE cdPerfil="+id+" and excluido='N'";
                    var data = con.Query<Perfil>(query).ToList();
                    return data;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }



        public virtual Perfil InserirPerfil(Perfil obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var Perfil = new Perfil(); 
                try
                {
                    con.Open();
                    var query = "INSERT INTO Perfil (cdPerfil, nomePerfil) VALUES ("+obj.cdperfil+",'" + obj.nomeperfil + "')";
                    con.Execute(query);
                    Perfil.cdperfil = obj.cdperfil;
                    Perfil.nomeperfil = obj.nomeperfil; 
                    Perfil.msg = "Incluido com Sucesso";
                    return Perfil;
                }
                catch (Exception ex)
                {
                    Perfil.msg = "Erro ao tentar Incluir verifique no log";
                    return Perfil;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
        public virtual Perfil AlterarPerfil(Perfil obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var Perfil = new Perfil();
                try
                {
                    con.Open();
                    var query = "UPDATE Perfil SET nomeperfil='" + obj.nomeperfil + "' WHERE cdperfil="+obj.cdperfil;
                    con.Execute(query);
                    Perfil.cdperfil = obj.cdperfil;
                    Perfil.nomeperfil = obj.nomeperfil;
                    Perfil.msg = "Alterado com Sucesso";
                    return Perfil;
                }
                catch (Exception ex)
                {
                    Perfil.msg = "Erro ao tentar Alterar verifique no log a causa";
                    return Perfil;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }




        public virtual Perfil DeletePerfil(Perfil obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var Perfil = new Perfil();
                try
                {
                    con.Open();
                    var query = "UPDATE Perfil SET excluido='S' WHERE cdPerfil=" + obj.cdperfil;
                    con.Execute(query);
                    Perfil.cdperfil = obj.cdperfil;
                    Perfil.nomeperfil = obj.nomeperfil;
                    Perfil.msg = "Perfil Excluido com Sucesso";
                    return Perfil;
                }
                catch (Exception ex)
                {
                    Perfil.msg = "Erro ao tentar Excluir o Perfil verifique no log a causa";
                    return Perfil;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
