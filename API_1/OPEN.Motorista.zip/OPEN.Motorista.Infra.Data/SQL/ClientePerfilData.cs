﻿using Dapper;
using Microsoft.Extensions.Configuration;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace OPEN.Motorista.Infra.Data
{
    public class ClientePerfilData
    {
        IConfiguration _configuration;

        public ClientePerfilData(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GetConnection()
        {
            var connection = _configuration.GetSection("ConnectionStrings").
            GetSection("DefaultConnection").Value;
            return connection;
        }
        /*public  virtual List<ClientePerfil> ObterCliente(int? id = 0, int? idperfil = 0)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                try
                {
                    con.Open();
                    var query = "SELECT cdCliente, cdPerfil FROM ClientePerfil WHERE cdCliente="+id+" and cdPerfil="+idperfil+" excluido='N'";
                    var data = con.Query<ClientePerfil>(query).ToList();
                    return data;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }*/



        public virtual ClientePerfil InserirCliente(ClientePerfil obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var cliente = new ClientePerfil(); 
                try
                {
                    con.Open();
                    var query = "INSERT INTO ClientePerfil (cdCliente, cdPerfil) VALUES ("+obj.cdCliente+",'" + obj.cdPerfil + "')";
                    con.Execute(query);
                    cliente.cdCliente = obj.cdCliente;
                    cliente.cdPerfil = obj.cdPerfil; 
                    cliente.msg = "Incluido ClientePerfil com Sucesso";
                    return cliente;
                }
                catch (Exception ex)
                {
                    cliente.msg = "Erro ao tentar Incluir verifique no log";
                    return cliente;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }



        public virtual ClientePerfil DeleteCliente(ClientePerfil obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var cliente = new ClientePerfil();
                try
                {
                    con.Open();
                    var query = "UPDATE ClientePerfil SET excluido='S' WHERE cdCliente=" + obj.cdCliente+" and cdPerfil="+obj.cdPerfil;
                    con.Execute(query);
                    cliente.cdCliente = obj.cdCliente;
                    cliente.cdPerfil = obj.cdPerfil;
                    cliente.msg = "CLientePerfil Excluido com Sucesso";
                    return cliente;
                }
                catch (Exception ex)
                {
                    cliente.msg = "Erro ao tentar Excluir o ClientePerfil verifique no log a causa";
                    return cliente;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
