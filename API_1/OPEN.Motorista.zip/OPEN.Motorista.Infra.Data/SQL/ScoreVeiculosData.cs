﻿using Dapper;
using Microsoft.Extensions.Configuration;
using OPEN.Motorista.Dominio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace OPEN.Motorista.Infra.Data
{
    public class ScoreVeiculosData
    {
        IConfiguration _configuration;

        public ScoreVeiculosData(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GetConnection()
        {
            var connection = _configuration.GetSection("ConnectionStrings").
            GetSection("DefaultConnection").Value;
            return connection;
        }
        public  virtual List<ScoreVeiculos> ObterScore(int? idpessoa = 0)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                try
                {
                    con.Open();
                    var query = "SELECT placa, cdcliente, cdperfil, score, dtcalculo FROM ScoreVeiculos WHERE documentopessoa="+ idpessoa + " and excluido='N'";
                    var data = con.Query<ScoreVeiculos>(query).ToList();
                    return data;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
       
    }
}
