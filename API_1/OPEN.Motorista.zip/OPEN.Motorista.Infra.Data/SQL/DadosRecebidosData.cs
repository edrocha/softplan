﻿using Dapper;
using Microsoft.Extensions.Configuration;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace OPEN.Motorista.Infra.Data
{
    public class DadosRecebidosData
    {
        IConfiguration _configuration;

        public DadosRecebidosData(IConfiguration configuration)
        {
            _configuration = configuration;
        }
         

        public string GetConnection()
        {
            var connection = _configuration.GetSection("ConnectionStrings").
            GetSection("DefaultConnection").Value;
            return connection;
        }
        public virtual List<DadosRecebidos> ObterDadosRecebidos(int? id = 0)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                try
                {
                    con.Open();
                    var query = "Select * from dadosrecebidos D ";
                    query += "INNER JOIN Item I ON D.cditem = I.cditem ";
                    query += " inner join veiculos V ";
                    query += "ON V.cdveiculo = D.cdveiculo";
                    var data = con.Query<DadosRecebidos>(query).ToList();
                    return data;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }



        public virtual DadosRecebidos InserirDadosRecebidos(DadosRecebidos obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var dados  = new DadosRecebidos();
                
                try
                {
                    con.Open();
                    var query = "insert into dadosrecebidos  (documentopessoa, datarecebido, cditem, quantidade, situacao, cdveiculo) values  (";
                    query += obj.datarecebido + ',' + DateTime.Today.ToString() + ",";
                    query += obj.item.cdItem+",";
                    query += obj.quantidade + ",";
                    query += obj.situacao + ")";
                    con.Execute(query);

                    dados.documentopessoa = obj.documentopessoa;
                    dados.quantidade = obj.quantidade;
                    dados.msg = "Dadosrecebidos Incluido com Sucesso";
                    return dados;
                }
                catch (Exception ex)
                {
                    dados.msg = "Erro ao tentar Incluir verifique no log";
                    return dados;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }

/*        public virtual Clientes DeleteDadosRecebidos(Clientes obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var cliente = new Clientes();
                try
                {
                    con.Open();
                    var query = "UPDATE dadosrecebidos SET excluido='S' WHERE cdCliente=" + obj.cdCliente;
                    con.Execute(query);
                    cliente.cdCliente = obj.cdCliente;
                    cliente.nomeCliente = obj.nomeCliente;
                    cliente.msg = "CLiente Excluido com Sucesso";
                    return cliente;
                }
                catch (Exception ex)
                {
                    cliente.msg = "Erro ao tentar Excluir o cliente verifique no log a causa";
                    return cliente;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }*/

    }
}
