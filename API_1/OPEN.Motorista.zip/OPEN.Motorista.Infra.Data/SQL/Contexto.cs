﻿using OPEN.Motorista.CrossCutting.Log;
using System;
using System.Collections.Generic;
using System.Text;

namespace OPEN.Motorista.Infra.Data
{
    public class Contexto
    {
        public  bool TesteConnection()
        {
             try
            {
                // MarcaEmpresaData me = new MarcaEmpresaData();
                //---------------------------------------------------------------------
               
               
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Logger.Error("Contexto/TesteConnection", ex);
                return false;

            }
        }
    }
}
