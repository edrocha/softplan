﻿using Dapper;
using Microsoft.Extensions.Configuration;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace OPEN.Motorista.Infra.Data
{
    public class ClientesData
    {
        IConfiguration _configuration;

        public ClientesData(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GetConnection()
        {
            var connection = _configuration.GetSection("ConnectionStrings").
            GetSection("DefaultConnection").Value;
            return connection;
        }
        public  virtual List<Clientes> ObterCliente(int? id = 0)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                try
                {
                    con.Open();
                    var query = "SELECT cdCliente, nomeCliente FROM clientes WHERE cdCliente="+id+" and excluido='N'";
                    var data = con.Query<Clientes>(query).ToList();
                    return data;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }



        public virtual Clientes InserirCliente(Clientes obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var cliente = new Clientes(); 
                try
                {
                    con.Open();
                    var query = "INSERT INTO clientes (cdCliente, nomeCliente) VALUES ("+obj.cdCliente+",'" + obj.nomeCliente + "')";
                    con.Execute(query);
                    cliente.cdCliente = obj.cdCliente;
                    cliente.nomeCliente = obj.nomeCliente; 
                    cliente.msg = "Incluido com Sucesso";
                    return cliente;
                }
                catch (Exception ex)
                {
                    cliente.msg = "Erro ao tentar Incluir verifique no log";
                    return cliente;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
        public virtual Clientes AlterarCliente(Clientes obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var cliente = new Clientes();
                try
                {
                    con.Open();
                    var query = "UPDATE clientes SET nomeCliente='" + obj.nomeCliente + "' WHERE cdCliente="+obj.cdCliente;
                    con.Execute(query);
                    cliente.cdCliente = obj.cdCliente;
                    cliente.nomeCliente = obj.nomeCliente;
                    cliente.msg = "Alterado com Sucesso";
                    return cliente;
                }
                catch (Exception ex)
                {
                    cliente.msg = "Erro ao tentar Alterar verifique no log a causa";
                    return cliente;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }




        public virtual Clientes DeleteCliente(Clientes obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var cliente = new Clientes();
                try
                {
                    con.Open();
                    var query = "UPDATE clientes SET excluido='S' WHERE cdCliente=" + obj.cdCliente;
                    con.Execute(query);
                    cliente.cdCliente = obj.cdCliente;
                    cliente.nomeCliente = obj.nomeCliente;
                    cliente.msg = "CLiente Excluido com Sucesso";
                    return cliente;
                }
                catch (Exception ex)
                {
                    cliente.msg = "Erro ao tentar Excluir o cliente verifique no log a causa";
                    return cliente;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
