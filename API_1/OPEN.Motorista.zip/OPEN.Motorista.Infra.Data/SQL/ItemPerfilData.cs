﻿using Dapper;
using Microsoft.Extensions.Configuration;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace OPEN.Motorista.Infra.Data
{
    public class ItemPerfilData
    {
        IConfiguration _configuration;

        public ItemPerfilData(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GetConnection()
        {
            var connection = _configuration.GetSection("ConnectionStrings").
            GetSection("DefaultConnection").Value;
            return connection;
        }
        public  virtual List<ItemPerfil> ObterItemPerfil(int? id = 0, int? idperfil=0)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                try
                {
                    con.Open();
                    var query = "SELECT cdItem, valoritem, cdPerfil   FROM ItemPerfil WHERE cdItem="+id+" and cdperfil="+idperfil+" excluido='N'";
                    var data = con.Query<ItemPerfil>(query).ToList();
                    return data;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }



        public virtual ItemPerfil InserirItemPerfil(ItemPerfil obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var ItemPerfil = new ItemPerfil(); 
                try
                {
                    con.Open();
                    var query = "INSERT INTO ItemPerfil (cdItem, valorItem, cdperfil ) VALUES ("+obj.cditem+",'" + obj.valoritem + ",'" + obj.cdperfil + "')";
                    con.Execute(query);
                    ItemPerfil.cditem = obj.cditem;
                    ItemPerfil.valoritem = obj.valoritem; 
                    ItemPerfil.msg = "Incluido com Sucesso";
                    return ItemPerfil;
                }
                catch (Exception ex)
                {
                    ItemPerfil.msg = "Erro ao tentar Incluir verifique no log";
                    return ItemPerfil;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
        public virtual ItemPerfil AlterarItemPerfil(ItemPerfil obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var ItemPerfil = new ItemPerfil();
                try
                {
                    con.Open();
                    var query = "UPDATE ItemPerfil SET valoritem='" + obj.valoritem + "' WHERE cdItem="+obj.cditem+" and cdperfil="+obj.cdperfil;
                    con.Execute(query);
                    ItemPerfil.cditem = obj.cditem;
                    ItemPerfil.cdperfil = obj.cdperfil;
                    ItemPerfil.valoritem = obj.valoritem;

                    ItemPerfil.msg = "Alterado com Sucesso";
                    return ItemPerfil;
                }
                catch (Exception ex)
                {
                    ItemPerfil.msg = "Erro ao tentar Alterar verifique no log a causa";
                    return ItemPerfil;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }




        public virtual ItemPerfil DeleteItemPerfil(ItemPerfil obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var ItemPerfil = new ItemPerfil();
                try
                {
                    con.Open();
                    var query = "UPDATE ItemPerfil SET excluido='S' WHERE cdItem=" + obj.cditem+ "and cdperfil="+obj.cdperfil;
                    con.Execute(query);
                    ItemPerfil.cditem = obj.cditem;
                    ItemPerfil.cdperfil = obj.cdperfil;
                    ItemPerfil.valoritem = obj.valoritem;

                    ItemPerfil.msg = "ItemPerfil Excluido com Sucesso";
                    return ItemPerfil;
                }
                catch (Exception ex)
                {
                    ItemPerfil.msg = "Erro ao tentar Excluir o ItemPerfil verifique no log a causa";
                    return ItemPerfil;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
