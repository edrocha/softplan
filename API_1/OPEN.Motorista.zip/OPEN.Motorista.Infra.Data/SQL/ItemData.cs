﻿using Dapper;
using Microsoft.Extensions.Configuration;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace OPEN.Motorista.Infra.Data
{
    public class ItemData
    {
        IConfiguration _configuration;

        public ItemData(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GetConnection()
        {
            var connection = _configuration.GetSection("ConnectionStrings").
            GetSection("DefaultConnection").Value;
            return connection;
        }
        public  virtual List<Item> ObterItem(int? id = 0)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                try
                {
                    con.Open();
                    var query = "SELECT cdItem, nomeItem FROM Item WHERE cdItem="+id+" and excluido='N'";
                    var data = con.Query<Item>(query).ToList();
                    return data;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }



        public virtual Item InserirItem(Item obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var Item = new Item(); 
                try
                {
                    con.Open();
                    var query = "INSERT INTO Item (cdItem, nomeItem) VALUES ("+obj.cdItem+",'" + obj.nomeItem + "')";
                    con.Execute(query);
                    Item.cdItem = obj.cdItem;
                    Item.nomeItem = obj.nomeItem; 
                    Item.msg = "Incluido com Sucesso";
                    return Item;
                }
                catch (Exception ex)
                {
                    Item.msg = "Erro ao tentar Incluir verifique no log";
                    return Item;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
        public virtual Item AlterarItem(Item obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var Item = new Item();
                try
                {
                    con.Open();
                    var query = "UPDATE Item SET nomeItem='" + obj.nomeItem + "' WHERE cdItem="+obj.cdItem;
                    con.Execute(query);
                    Item.cdItem = obj.cdItem;
                    Item.nomeItem = obj.nomeItem;
                    Item.msg = "Alterado com Sucesso";
                    return Item;
                }
                catch (Exception ex)
                {
                    Item.msg = "Erro ao tentar Alterar verifique no log a causa";
                    return Item;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }




        public virtual Item DeleteItem(Item obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var Item = new Item();
                try
                {
                    con.Open();
                    var query = "UPDATE Item SET excluido='S' WHERE cdItem=" + obj.cdItem;
                    con.Execute(query);
                    Item.cdItem = obj.cdItem;
                    Item.nomeItem = obj.nomeItem;
                    Item.msg = "Item Excluido com Sucesso";
                    return Item;
                }
                catch (Exception ex)
                {
                    Item.msg = "Erro ao tentar Excluir o Item verifique no log a causa";
                    return Item;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
