﻿using Dapper;
using Microsoft.Extensions.Configuration;
using OPEN.Motorista.Dominio.Entidades;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace OPEN.Motorista.Infra.Data
{
    public class VeiculosData
    {
        IConfiguration _configuration;

        public VeiculosData(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GetConnection()
        {
            var connection = _configuration.GetSection("ConnectionStrings").
            GetSection("DefaultConnection").Value;
            return connection;
        }
        public  virtual List<Veiculos> ObterVeiculos(int? id = 0)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                try
                {
                    con.Open();
                    var query = "SELECT veiculo,placa FROM Veiculos WHERE cdVeiculos="+id+" and excluido='N'";
                    var data = con.Query<Veiculos>(query).ToList();
                    return data;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }



        public virtual Veiculos InserirVeiculos(Veiculos obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var Veiculos = new Veiculos(); 
                try
                {
                    con.Open();
                    var query = "INSERT INTO Veiculos (cdveiculos, tipoveiculo, placa) VALUES ("+obj.cdVeiculo+",'" + obj.tipoveiculo + "','" + obj.tipoveiculo + "')";
                    con.Execute(query);
                    Veiculos.cdVeiculo = obj.cdVeiculo;
                    Veiculos.tipoveiculo = obj.tipoveiculo;
                    Veiculos.placa = obj.placa;
                    Veiculos.msg = "Incluido com Sucesso";
                    return Veiculos;
                }
                catch (Exception ex)
                {
                    Veiculos.msg = "Erro ao tentar Incluir verifique no log";
                    return Veiculos;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
        public virtual Veiculos AlterarVeiculos(Veiculos obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var Veiculos = new Veiculos();
                try
                {
                    con.Open();
                    var query = "UPDATE Veiculos SET placa ='" + obj.placa + ", tipoveiculo='"+obj.tipoveiculo+"', cdveiculo="+obj.cdVeiculo+" WHERE cdVeiculo="+obj.cdVeiculo;
                    con.Execute(query);
                    Veiculos.cdVeiculo = obj.cdVeiculo;
                    Veiculos.placa = obj.placa;
                    Veiculos.tipoveiculo = obj.tipoveiculo;

                    Veiculos.msg = "Alterado com Sucesso";
                    return Veiculos;
                }
                catch (Exception ex)
                {
                    Veiculos.msg = "Erro ao tentar Alterar verifique no log a causa";
                    return Veiculos;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }




        public virtual Veiculos DeleteVeiculos(Veiculos obj)
        {
            using (var con = new SqlConnection(GetConnection()))
            {
                var Veiculos = new Veiculos();
                try
                {
                    con.Open();
                    var query = "UPDATE Veiculos SET excluido='S' WHERE cdVeiculo=" + obj.cdVeiculo;
                    con.Execute(query);
                    Veiculos.cdVeiculo = obj.cdVeiculo;
                    Veiculos.tipoveiculo = obj.tipoveiculo;
                    Veiculos.placa = obj.placa;
                    Veiculos.msg = "Veiculos Excluido com Sucesso";
                    return Veiculos;
                }
                catch (Exception ex)
                {
                    Veiculos.msg = "Erro ao tentar Excluir o Veiculos verifique no log a causa";
                    return Veiculos;
                    //throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
