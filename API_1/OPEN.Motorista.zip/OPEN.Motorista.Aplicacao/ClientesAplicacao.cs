﻿using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using OPEN.Motorista.Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OPEN.Motorista.Aplicacao
{
    public class ClientesAplicacao : IClientesAplicacao
    {
        public IClientes _ClientesRepositorio { get; set; }


        public ClientesAplicacao(IClientes clientesRepositorio)
        {
            _ClientesRepositorio = clientesRepositorio;
        }

        public List<Clientes> Obter(int id)
        {
            try
            {
                return _ClientesRepositorio.Obter(id);
            }
            catch (Exception ex)
            {
                Logger.Error("ClientesAplicacao", ex);
                throw;
            }
        }

        public Clientes Cadastrar(Clientes cliente)
        {
            try
            {
                return _ClientesRepositorio.Cadastrar(cliente);
            }
            catch (Exception ex)
            {
                Logger.Error("ClientesAplicacao", ex);
                throw;
            }
        }

        public Clientes Alterar(Clientes cliente)
        {
            try
            {
                return _ClientesRepositorio.Alterar(cliente);
            }
            catch (Exception ex)
            {
                Logger.Error("ClientesAplicacao/Alterar", ex);
                throw;
            }
        }

        public Clientes Deletar(Clientes cliente)
        {
            try
            {
                return _ClientesRepositorio.Deletar(cliente);
            }
            catch (Exception ex)
            {
                Logger.Error("ClientesAplicacao/Deletar", ex);
                throw;
            }
        }
    }
}
