﻿using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using OPEN.Motorista.Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OPEN.Motorista.Aplicacao
{
    public class ScoreMotoristaAplicacao : IScoreMotoristaAplicacao
    {
        public IScoreMotorista _ScoreMotoristaRepositorio { get; set; }


        public ScoreMotoristaAplicacao(IScoreMotorista ScoreMotoristaRepositorio)
        {
            _ScoreMotoristaRepositorio = ScoreMotoristaRepositorio;
        }

        public List<ScoreMotorista> Obter(int id)
        {
            try
            {
                return _ScoreMotoristaRepositorio.Obter(id);
            }
            catch (Exception ex)
            {
                Logger.Error("ScoreMotoristaAplicacao", ex);
                throw;
            }
        }
    }
}
