﻿
using OPEN.Motorista.Dominio.Entidades;
using System.Collections.Generic;

namespace OPEN.Motorista.Aplicacao.Interfaces
{
    public interface IVeiculosAplicacao
    {
        List<Veiculos> Obter(int id);
        Veiculos Cadastrar(Veiculos Veiculos);
        Veiculos Alterar(Veiculos Veiculos);
        Veiculos Deletar(Veiculos Veiculos);
    }
}
