﻿
using OPEN.Motorista.Dominio.Entidades;
using System.Collections.Generic;

namespace OPEN.Motorista.Aplicacao.Interfaces
{
    public interface IItemAplicacao
    {
        List<Item> Obter(int id);
        Item Cadastrar(Item Item);
        Item Alterar(Item Item);
        Item Deletar(Item Item);
    }
}
