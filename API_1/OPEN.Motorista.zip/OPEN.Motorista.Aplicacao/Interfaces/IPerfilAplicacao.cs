﻿
using OPEN.Motorista.Dominio.Entidades;
using System.Collections.Generic;

namespace OPEN.Motorista.Aplicacao.Interfaces
{
    public interface IPerfilAplicacao
    {
        List<Perfil> Obter(int id);
        Perfil Cadastrar(Perfil Perfil);
        Perfil Alterar(Perfil Perfil);
        Perfil Deletar(Perfil Perfil);
    }
}
