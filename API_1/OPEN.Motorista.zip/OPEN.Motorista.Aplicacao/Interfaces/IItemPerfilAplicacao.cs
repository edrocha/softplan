﻿
using OPEN.Motorista.Dominio.Entidades;
using System.Collections.Generic;

namespace OPEN.Motorista.Aplicacao.Interfaces
{
    public interface IItemPerfilAplicacao
    {
        List<ItemPerfil> Obter(int id);
        ItemPerfil Cadastrar(ItemPerfil ItemPerfil);
        ItemPerfil Alterar(ItemPerfil ItemPerfil);
        ItemPerfil Deletar(ItemPerfil ItemPerfil);
    }
}
