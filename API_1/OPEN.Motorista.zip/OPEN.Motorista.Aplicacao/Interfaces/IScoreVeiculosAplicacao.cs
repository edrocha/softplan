﻿
using OPEN.Motorista.Dominio.Entidades;
using System.Collections.Generic;

namespace OPEN.Motorista.Aplicacao.Interfaces
{
    public interface IScoreVeiculosAplicacao
    {
        List<ScoreVeiculos> Obter(int id);
    }
}
