﻿
using OPEN.Motorista.Dominio.Entidades;
using System.Collections.Generic;

namespace OPEN.Motorista.Aplicacao.Interfaces
{
    public interface IDadosRecebidosAplicacao
    {
        List<DadosRecebidos> Obter(int id);
        DadosRecebidos Cadastrar(DadosRecebidos DadosRecebidos);
        DadosRecebidos Alterar(DadosRecebidos DadosRecebidos);
        DadosRecebidos Deletar(DadosRecebidos DadosRecebidos);
    }
}
