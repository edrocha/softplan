﻿
using OPEN.Motorista.Dominio.Entidades;
using System.Collections.Generic;

namespace OPEN.Motorista.Aplicacao.Interfaces
{
    public interface IClientePerfilAplicacao
    {
        ClientePerfil Cadastrar(ClientePerfil cliente);
        ClientePerfil Deletar(ClientePerfil cliente);
    }
}
