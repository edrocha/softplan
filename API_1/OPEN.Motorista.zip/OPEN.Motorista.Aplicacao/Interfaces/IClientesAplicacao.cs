﻿
using OPEN.Motorista.Dominio.Entidades;
using System.Collections.Generic;

namespace OPEN.Motorista.Aplicacao.Interfaces
{
    public interface IClientesAplicacao
    {
        List<Clientes> Obter(int id);
        Clientes Cadastrar(Clientes cliente);
        Clientes Alterar(Clientes cliente);
        Clientes Deletar(Clientes cliente);
    }
}
