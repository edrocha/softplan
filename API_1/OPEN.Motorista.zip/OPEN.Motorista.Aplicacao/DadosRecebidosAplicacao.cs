﻿using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using OPEN.Motorista.Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OPEN.Motorista.Aplicacao
{
    public class DadosRecebidosAplicacao : IDadosRecebidosAplicacao
    {
        public IDadosRecebidos _DadosRecebidosRepositorio { get; set; }


        public DadosRecebidosAplicacao(IDadosRecebidos DadosRecebidosRepositorio)
        {
            _DadosRecebidosRepositorio = DadosRecebidosRepositorio;
        }

        public List<DadosRecebidos> Obter(int id)
        {
            try
            {
                return _DadosRecebidosRepositorio.Obter(id);
            }
            catch (Exception ex)
            {
                Logger.Error("DadosRecebidosAplicacao", ex);
                throw;
            }
        }

        public DadosRecebidos Cadastrar(DadosRecebidos DadosRecebidos)
        {
            try
            {
                return _DadosRecebidosRepositorio.Cadastrar(DadosRecebidos);
            }
            catch (Exception ex)
            {
                Logger.Error("DadosRecebidosAplicacao", ex);
                throw;
            }
        }

        public DadosRecebidos Alterar(DadosRecebidos DadosRecebidos)
        {
            try
            {
                return _DadosRecebidosRepositorio.Alterar(DadosRecebidos);
            }
            catch (Exception ex)
            {
                Logger.Error("DadosRecebidosAplicacao/Alterar", ex);
                throw;
            }
        }

        public DadosRecebidos Deletar(DadosRecebidos DadosRecebidos)
        {
            try
            {
                return _DadosRecebidosRepositorio.Deletar(DadosRecebidos);
            }
            catch (Exception ex)
            {
                Logger.Error("DadosRecebidosAplicacao/Deletar", ex);
                throw;
            }
        }
    }
}
