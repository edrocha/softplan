﻿using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using OPEN.Motorista.Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OPEN.Motorista.Aplicacao
{
    public class ItemAplicacao : IItemAplicacao
    {
        public IItem _ItemRepositorio { get; set; }


        public ItemAplicacao(IItem ItemRepositorio)
        {
            _ItemRepositorio = ItemRepositorio;
        }

        public List<Item> Obter(int id)
        {
            try
            {
                return _ItemRepositorio.Obter(id);
            }
            catch (Exception ex)
            {
                Logger.Error("ItemAplicacao", ex);
                throw;
            }
        }

        public Item Cadastrar(Item Item)
        {
            try
            {
                return _ItemRepositorio.Cadastrar(Item);
            }
            catch (Exception ex)
            {
                Logger.Error("ItemAplicacao", ex);
                throw;
            }
        }

        public Item Alterar(Item Item)
        {
            try
            {
                return _ItemRepositorio.Alterar(Item);
            }
            catch (Exception ex)
            {
                Logger.Error("ItemAplicacao/Alterar", ex);
                throw;
            }
        }

        public Item Deletar(Item Item)
        {
            try
            {
                return _ItemRepositorio.Deletar(Item);
            }
            catch (Exception ex)
            {
                Logger.Error("ItemAplicacao/Deletar", ex);
                throw;
            }
        }
    }
}
