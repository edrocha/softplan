﻿using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using OPEN.Motorista.Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OPEN.Motorista.Aplicacao
{
    public class ScoreVeiculosAplicacao : IScoreVeiculosAplicacao
    {
        public IScoreVeiculos _ScoreVeiculosRepositorio { get; set; }


        public ScoreVeiculosAplicacao(IScoreVeiculos ScoreVeiculosRepositorio)
        {
            _ScoreVeiculosRepositorio = ScoreVeiculosRepositorio;
        }

        public List<ScoreVeiculos> Obter(int id)
        {
            try
            {
                return _ScoreVeiculosRepositorio.Obter(id);
            }
            catch (Exception ex)
            {
                Logger.Error("ScoreVeiculosAplicacao", ex);
                throw;
            }
        }
    }
}
