﻿using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using OPEN.Motorista.Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OPEN.Motorista.Aplicacao
{
    public class VeiculosAplicacao : IVeiculosAplicacao
    {
        public IVeiculos _VeiculosRepositorio { get; set; }


        public VeiculosAplicacao(IVeiculos VeiculosRepositorio)
        {
            _VeiculosRepositorio = VeiculosRepositorio;
        }

        public List<Veiculos> Obter(int id)
        {
            try
            {
                return _VeiculosRepositorio.Obter(id);
            }
            catch (Exception ex)
            {
                Logger.Error("VeiculosAplicacao", ex);
                throw;
            }
        }

        public Veiculos Cadastrar(Veiculos Veiculos)
        {
            try
            {
                return _VeiculosRepositorio.Cadastrar(Veiculos);
            }
            catch (Exception ex)
            {
                Logger.Error("VeiculosAplicacao", ex);
                throw;
            }
        }

        public Veiculos Alterar(Veiculos Veiculos)
        {
            try
            {
                return _VeiculosRepositorio.Alterar(Veiculos);
            }
            catch (Exception ex)
            {
                Logger.Error("VeiculosAplicacao/Alterar", ex);
                throw;
            }
        }

        public Veiculos Deletar(Veiculos Veiculos)
        {
            try
            {
                return _VeiculosRepositorio.Deletar(Veiculos);
            }
            catch (Exception ex)
            {
                Logger.Error("VeiculosAplicacao/Deletar", ex);
                throw;
            }
        }
    }
}
