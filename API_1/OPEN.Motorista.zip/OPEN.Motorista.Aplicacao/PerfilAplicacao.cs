﻿using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using OPEN.Motorista.Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OPEN.Motorista.Aplicacao
{
    public class PerfilAplicacao : IPerfilAplicacao
    {
        public IPerfil _PerfilRepositorio { get; set; }


        public PerfilAplicacao(IPerfil PerfilRepositorio)
        {
            _PerfilRepositorio = PerfilRepositorio;
        }

        public List<Perfil> Obter(int id)
        {
            try
            {
                return _PerfilRepositorio.Obter(id);
            }
            catch (Exception ex)
            {
                Logger.Error("PerfilAplicacao", ex);
                throw;
            }
        }

        public Perfil Cadastrar(Perfil Perfil)
        {
            try
            {
                return _PerfilRepositorio.Cadastrar(Perfil);
            }
            catch (Exception ex)
            {
                Logger.Error("PerfilAplicacao", ex);
                throw;
            }
        }

        public Perfil Alterar(Perfil Perfil)
        {
            try
            {
                return _PerfilRepositorio.Alterar(Perfil);
            }
            catch (Exception ex)
            {
                Logger.Error("PerfilAplicacao/Alterar", ex);
                throw;
            }
        }

        public Perfil Deletar(Perfil Perfil)
        {
            try
            {
                return _PerfilRepositorio.Deletar(Perfil);
            }
            catch (Exception ex)
            {
                Logger.Error("PerfilAplicacao/Deletar", ex);
                throw;
            }
        }
    }
}
