﻿using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using OPEN.Motorista.Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OPEN.Motorista.Aplicacao
{
    public class ItemPerfilAplicacao : IItemPerfilAplicacao
    {
        public IItemPerfil _ItemPerfilRepositorio { get; set; }


        public ItemPerfilAplicacao(IItemPerfil ItemPerfilRepositorio)
        {
            _ItemPerfilRepositorio = ItemPerfilRepositorio;
        }

        public List<ItemPerfil> Obter(int id)
        {
            try
            {
                return _ItemPerfilRepositorio.Obter(id);
            }
            catch (Exception ex)
            {
                Logger.Error("ItemPerfilAplicacao", ex);
                throw;
            }
        }

        public ItemPerfil Cadastrar(ItemPerfil ItemPerfil)
        {
            try
            {
                return _ItemPerfilRepositorio.Cadastrar(ItemPerfil);
            }
            catch (Exception ex)
            {
                Logger.Error("ItemPerfilAplicacao", ex);
                throw;
            }
        }

        public ItemPerfil Alterar(ItemPerfil ItemPerfil)
        {
            try
            {
                return _ItemPerfilRepositorio.Alterar(ItemPerfil);
            }
            catch (Exception ex)
            {
                Logger.Error("ItemPerfilAplicacao/Alterar", ex);
                throw;
            }
        }

        public ItemPerfil Deletar(ItemPerfil ItemPerfil)
        {
            try
            {
                return _ItemPerfilRepositorio.Deletar(ItemPerfil);
            }
            catch (Exception ex)
            {
                Logger.Error("ItemPerfilAplicacao/Deletar", ex);
                throw;
            }
        }
    }
}
