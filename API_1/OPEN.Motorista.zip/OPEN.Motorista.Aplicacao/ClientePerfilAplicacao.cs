﻿using OPEN.Motorista.Aplicacao.Interfaces;
using OPEN.Motorista.CrossCutting.Log;
using OPEN.Motorista.Dominio.Entidades;
using OPEN.Motorista.Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OPEN.Motorista.Aplicacao
{
    public class ClientePerfilAplicacao : IClientePerfilAplicacao
    {
        public IClientePerfil _ClientePerfilRepositorio { get; set; }


        public ClientePerfilAplicacao(IClientePerfil ClientePerfilRepositorio)
        {
            _ClientePerfilRepositorio = ClientePerfilRepositorio;
        }
        public ClientePerfil Cadastrar(ClientePerfil cliente)
        {
            try
            {
                return _ClientePerfilRepositorio.Cadastrar(cliente);
            }
            catch (Exception ex)
            {
                Logger.Error("ClientePerfilAplicacao", ex);
                throw;
            }
        }

        public ClientePerfil Deletar(ClientePerfil cliente)
        {
            try
            {
                return _ClientePerfilRepositorio.Deletar(cliente);
            }
            catch (Exception ex)
            {
                Logger.Error("ClientePerfilAplicacao/Deletar", ex);
                throw;
            }
        }
    }
}
